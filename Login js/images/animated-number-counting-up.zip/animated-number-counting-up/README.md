# Simple-jQuery-Counter
Simple jQuery Counter Script


Demo Link : https://simple-jquery-counter.netlify.app/
